This is a simple presentation package for "genai".
    
Contents:
- presentation-content.txt: Plain text version of the presentation
- presentation-viewer.html: HTML version that can be viewed in any browser

Note: This is a fallback format provided when PowerPoint generation was not possible.
