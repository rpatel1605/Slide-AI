# prof b thangaraju

## Introduction: Prof. B. Thangaraju

This presentation provides an overview of the academic and professional journey of Prof. B. Thangaraju, a distinguished figure in the field of computer science.

## Educational Background

Prof. B. Thangaraju holds a Ph.D. in Physics, demonstrating a strong foundation in fundamental sciences which complements his later work in computing.

## Early Research Career

He served as a Research Associate at the prestigious Indian Institute of Science (IISc.), Bangalore, from 1996 to 2001. This period was crucial for his research development.

## Transition to Academia

Following his research tenure, Prof. Thangaraju transitioned into a full-time academic role, bringing his research experience to teaching and mentorship.

## Role at IIIT Bangalore

Currently, Prof. B. Thangaraju is a Professor at the International Institute of Information Technology, Bangalore (IIIT Bangalore).

## Academic Department

He is a faculty member in the Computer Science discipline at IIIT Bangalore, contributing significantly to the department's academic and research activities.

## Research Interests

While his early background is in Physics, his work at IIIT Bangalore focuses on areas within Computer Science, indicating a diverse range of academic pursuits and adaptability.

## Research Output and Publications

Prof. Thangaraju has a presence on platforms like Google Scholar, which indexes his research papers and citations, reflecting his contributions to academic literature.

## Professional and Online Presence

He maintains a professional profile on platforms like LinkedIn and has a presence on GitHub, suggesting involvement in the open-source community or software development aspects related to his research.

## Contributions to Education and Research

Throughout his career, Prof. Thangaraju has contributed to shaping the next generation of computer scientists through teaching and has advanced knowledge through his research.

## Summary of Career Path

His career path shows a progression from fundamental science research to applied computer science within a leading technical institute, highlighting a unique interdisciplinary journey.

## Conclusion

Prof. B. Thangaraju's career is marked by a strong academic foundation, significant research experience, and dedicated service as a professor, making him a respected figure in his field.

