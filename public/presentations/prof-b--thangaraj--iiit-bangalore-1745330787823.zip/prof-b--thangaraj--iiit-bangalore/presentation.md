# Prof B. Thangaraj, IIIT Bangalore

## Prof. B. Thangaraj: Profile & Contributions

An Overview of His Work and Role at the International Institute of Information Technology Bangalore (IIITB)

## Introduction: Meet Prof. B. Thangaraj

- Professor at IIIT Bangalore.
- Distinguished academician and researcher in Operations Research and related fields.
- Contributes significantly to IIITB's teaching, research, and administrative activities.

## Academic Journey

- **PhD:** Operations Research, Anna University, Chennai.
- **MSc:** Mathematics, University of Madras.
- Strong foundation in mathematical sciences, underpinning his research and teaching.

## Core Expertise: Operations Research (OR)

- Deep knowledge in classical and modern OR techniques.
- Focus on mathematical modeling and optimization.
- Application of OR principles to solve complex decision-making problems.

## Bridging OR with Data Science & ML

- Integrates OR techniques with Machine Learning (ML) and Data Mining.
- Explores synergies between optimization and data-driven approaches.
- Develops hybrid models for enhanced predictive and prescriptive analytics.

## Key Research Interests

- Operations Research & Optimization Techniques
- Machine Learning & Data Mining
- Mathematical Modeling
- Supply Chain Management
- Algorithm Design & Analysis

## Research Contributions & Applications

- Focus on developing efficient algorithms and models for real-world challenges.
- Contributions often lie at the intersection of theory and practical application.
- Work potentially impacts areas like logistics, resource allocation, and business intelligence.

## Teaching & Pedagogy @ IIITB

- Teaches fundamental and advanced courses across various programs (iMTech, MTech, PhD).
- Key Courses Include:
  - Operations Research
  - Optimization Techniques
  - Probability & Statistics
  - Data Mining
  - Machine Learning

## Mentorship & Student Guidance

- Actively supervises PhD and Masters students.
- Guides research projects in his areas of expertise.
- Fosters critical thinking and research skills among students.
- Contributes to developing the next generation of researchers and professionals.

## Publications & Scholarly Impact

- Author of numerous research papers in reputed journals and conferences.
- Disseminates research findings globally.
- Active participant in the academic community through publications and presentations.
- Citation records reflect the impact of his work (refer to Google Scholar/DBLP for details).

## Institutional & Professional Roles

- Contributes to IIITB through participation in various academic and administrative committees (e.g., Admissions, Academic Council, Curriculum Development).
- Engages with the broader academic and professional community in OR and Data Science.

## Current Focus & Future Directions

- Continues research on advanced optimization techniques and their application.
- Exploring novel integrations of OR and AI/ML for complex systems.
- Focus on solving contemporary problems using quantitative methods.

## Conclusion: Impact & Significance

- Prof. B. Thangaraj is a key faculty member at IIIT Bangalore with significant expertise in OR, Optimization, and Data Science.
- Makes substantial contributions through teaching, research, mentorship, and institutional service.
- His work bridges theoretical foundations with practical applications, enriching the academic environment at IIITB.

## Further Information

- For more details, please visit Prof. Thangaraj's official faculty profile on the IIIT Bangalore website:
- [https://www.iiitb.ac.in/faculty/b-thangaraj](https://www.iiitb.ac.in/faculty/b-thangaraj)

