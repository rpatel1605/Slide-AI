# prof b thangaraju

## Introduction: Prof. B. Thangaraju

This presentation provides an overview of the academic and professional journey of Prof. B. Thangaraju, highlighting his key contributions and career milestones.

## Educational Background

Prof. B. Thangaraju holds a Ph.D. in Physics, establishing a strong foundation in theoretical and analytical disciplines.

## Early Research Career at IISc

From 1996 to 2001, he served as a Research Associate at the prestigious Indian Institute of Science (IISc.), Bangalore, engaging in significant research activities.

## Transition to Computer Science

Following his work in Physics, Prof. Thangaraju transitioned his expertise and focus towards the field of Computer Science.

## Affiliation with IIIT Bangalore

He is currently a Professor of Computer Science at the International Institute of Information Technology, Bangalore (IIIT Bangalore), a leading institution in IT education and research.

## Role as an Educator

As a professor at IIIT Bangalore, he is involved in teaching, curriculum development, and mentoring students, contributing significantly to academic excellence.

## Research Interests and Focus

While specific areas are diverse, his background suggests research interests potentially at the intersection of theoretical sciences and computer science, or core areas within CS.

## Academic Contributions and Publications

Prof. Thangaraju has contributed to the academic landscape through his research, likely publishing in relevant journals and conferences, as indicated by his Google Scholar presence.

## Engagement with the Community

He has actively engaged with the broader technical community, including participation as a speaker at events like Open Source India.

## Contributions to Open Source/Technical Writing

His work includes contributions such as authoring articles for publications like Linux Gazette, demonstrating involvement in open source and technical communication.

## Impact on Students and Research

Through teaching and research guidance, Prof. Thangaraju has likely influenced numerous students and contributed to advancements in his areas of expertise.

## Summary of Career Path

Prof. Thangaraju's career path demonstrates a unique blend of foundational physics research and significant contributions to the field of Computer Science.

## Conclusion

Prof. B. Thangaraju stands as an accomplished academic and researcher, whose journey from Physics to Computer Science at IIIT Bangalore highlights a versatile and impactful career in technology and education.

