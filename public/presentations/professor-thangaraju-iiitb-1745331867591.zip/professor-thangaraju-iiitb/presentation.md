# professor Thangaraju Iiitb

## Introduction: Prof. B. Thangaraju

- Esteemed Faculty Member
- Department of Computer Science and Engineering (CSE)
- Indian Institute of Technology Bombay (IITB)
- Focus on Computer Systems and Software

## Areas of Expertise

- Primary focus on Computer Systems Software.
- Deep knowledge in fundamental and advanced concepts.
- Key areas include Operating Systems, Distributed Systems, and System Security.

## Teaching Contributions: Core Subjects

- Dedicated educator shaping future engineers.
- Teaches foundational courses within the CSE curriculum.
- Specifically known for instructing courses such as:
    - Operating Systems (OS)
    - Software Engineering

## Research Focus

- Active researcher in systems software.
- Explores challenges in building reliable, efficient, and secure systems.
- Contributes to advancements in operating system design and implementation principles.

## Impact at IIT Bombay

- Plays a crucial role in the academic and research environment of the CSE department.
- Mentors numerous students through courses and projects.
- Contributes significantly to IITB's strength in Computer Science education.

## Conclusion

- Prof. B. Thangaraju is a valuable asset to IIT Bombay's CSE Department.
- Significant contributions through teaching core subjects like Operating Systems and Software Engineering.
- Key figure in systems software education and research at IITB.

