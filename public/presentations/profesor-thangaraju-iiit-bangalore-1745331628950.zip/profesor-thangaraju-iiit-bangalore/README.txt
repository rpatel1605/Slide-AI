This is a presentation package for "profesor thangaraju iiit Bangalore".
    
Contents:
- presentation.pptx: PowerPoint version of the presentation (if available)
- presentation.md: Markdown version of the presentation
- presentation.html: HTML version that can be viewed in any browser
- presentation.txt: Plain text version of the presentation
