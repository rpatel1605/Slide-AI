# B thangaraju IIITB

## Introduction: Prof. B. Thangaraju, IIIT Bangalore

An Overview of a Distinguished Academician

- Senior Professor at the International Institute of Information Technology Bangalore (IIITB).
- Renowned expert in Computer Science, particularly in theoretical foundations.
- Significant contributions to research, teaching, and academic administration at IIITB.

## Academic Profile & Background

- **Highest Qualification:** Ph.D. in Computer Science and Automation from the Indian Institute of Science (IISc), Bangalore.
- **Foundation:** Strong academic background with Masters (M.E.) and Bachelors (B.E.) degrees in Computer Science & Engineering.
- **Affiliation:** Long-standing and integral faculty member at IIIT Bangalore.

## Role at IIIT Bangalore

- **Position:** Professor, Computer Science Division.
- **Tenure:** Associated with IIITB for a significant duration, contributing to its growth and academic excellence.
- **Involvement:** Deeply involved in shaping the academic landscape of the institute.

## Core Research Area: Algorithms & Data Structures

- **Focus:** Design and analysis of efficient algorithms and data structures.
- **Expertise:** Foundational aspects of computing, essential for solving complex computational problems.
- **Impact:** Research contributes to the fundamental understanding and application of efficient computation.

## Research Interests: Graph Theory & Algorithms

- **Specialization:** Exploring properties of graphs and developing algorithms for graph-related problems.
- **Applications:** Relevant to network analysis, optimization problems, social networks, and bioinformatics.
- **Contributions:** Advancements in theoretical graph algorithms and their practical implications.

## Research Interests: Computational Geometry

- **Area:** Algorithms for geometric problems.
- **Topics:** Problems involving points, lines, polygons, and higher-dimensional objects.
- **Relevance:** Crucial for computer graphics, robotics, geographic information systems (GIS), and computer-aided design (CAD).

## Research Interests: Theoretical Computer Science

- **Broad Focus:** Investigating the fundamental capabilities and limitations of computation.
- **Includes:** Complexity theory, computability theory, and algorithm analysis.
- **Goal:** Understanding the mathematical foundations underpinning computer science.

## Teaching & Pedagogy

- **Courses Taught:** Primarily core Computer Science subjects like:
  - Design and Analysis of Algorithms
  - Data Structures
  - Theory of Computation
  - Discrete Mathematics
- **Approach:** Known for rigorous teaching style, emphasizing deep understanding of fundamental concepts.

## Student Mentorship & Guidance

- **Role:** Actively supervises Ph.D. and Master's (M.Tech / M.S.) students.
- **Focus:** Guiding research in his areas of expertise.
- **Impact:** Nurturing the next generation of researchers and computer scientists.

## Publications & Scholarly Contributions

- **Output:** Authored numerous research papers published in reputed international conferences and peer-reviewed journals.
- **Dissemination:** Actively contributes to the academic community through publication and participation in scholarly events.
- **Recognition:** His work is cited by researchers globally, indicating its impact in the field.

## Administrative Roles & Contributions

- **Leadership:** Has held significant administrative positions at IIITB, including:
  - Dean (Academics)
  - Dean (Faculty)
- **Impact:** Played a key role in shaping academic policies, faculty affairs, and curriculum development at the institute.

## Overall Impact & Recognition

- **Esteemed Faculty:** A highly respected senior member of the IIITB faculty and the broader Computer Science community in India.
- **Expertise:** Recognized expert in algorithms and theoretical computer science.
- **Legacy:** Significant contributions to IIITB's academic standards, research output, and institutional governance.

## Conclusion

- Prof. B. Thangaraju is a cornerstone of the Computer Science division at IIIT Bangalore.
- His expertise spans critical areas like Algorithms, Graph Theory, and Computational Geometry.
- He has made invaluable contributions as a researcher, educator, mentor, and administrator.
- His work continues to influence students and the academic community.

## Thank You / Q&A

Thank you for your attention.

Questions?

