# Prof. B. Thangaraju, IIITB

## Prof. B. Thangaraju: An Overview

A Presentation on the Profile, Contributions, and Impact of Prof. B. Thangaraju at the International Institute of Information Technology Bangalore (IIITB)

## Introduction

• Prof. B. Thangaraju is a distinguished Professor at IIIT Bangalore.
• Known for his expertise in Data Management, Data Mining, and Big Data Analytics.
• Holds significant academic and administrative responsibilities within the institute.
• This presentation highlights his journey, research, teaching, and contributions.

## Educational Background

• Ph.D. in Computer Science and Engineering from Anna University, Chennai.
• M.E. in Computer Science and Engineering from Anna University, Chennai.
• B.E. in Computer Science and Engineering from Government College of Technology (GCT), Coimbatore.
• Strong academic foundation in Computer Science and Engineering.

## Professional Journey & Affiliation

• Joined IIIT Bangalore in January 2002.
• Over two decades of dedicated service to IIITB.
• Promoted through academic ranks to Professor.
• Prior experience likely includes academic or research positions post-PhD.

## Role at IIIT Bangalore

• Professor in the Computer Science domain.
• Served as Dean (Academics), playing a crucial role in shaping academic policies, curriculum development, and student affairs.
• Actively involved in various institute committees and initiatives.
• Mentors faculty, research scholars, and students.

## Core Research Areas

• Database Management Systems (DBMS)
• Data Warehousing and Data Mining
• Big Data Analytics
• Information Retrieval
• Web Mining
• Machine Learning Applications

## Key Research Contributions

• Focus on efficient data processing and knowledge discovery from large datasets.
• Contributions in areas like spatio-temporal data mining, stream data processing, and scalable algorithms for big data.
• Explored applications of data mining in diverse domains.
• Guided numerous PhD and Masters students on cutting-edge research topics.

## Publications and Scholarly Output

• Authored and co-authored numerous research papers in reputed international journals and conferences.
• Publications cover theoretical advancements and practical applications in his research areas.
• His work is cited by researchers globally, indicating its impact in the field.
• Contributes to the dissemination of knowledge through scholarly writing.

## Teaching and Pedagogy

• Teaches core and elective courses related to Databases, Data Mining, and Big Data Analytics at Masters and PhD levels.
• Known for his clear exposition of complex concepts.
• Integrates research insights into his teaching.
• Consistently receives positive feedback from students.

## Mentorship and Guidance

• Supervised a significant number of PhD and M.Tech research theses.
• Many of his students have gone on to successful careers in academia and industry.
• Provides strong mentorship, fostering critical thinking and research skills.
• Plays a vital role in nurturing the next generation of computer scientists.

## Administrative Leadership (Dean Academics)

• As Dean (Academics), oversaw academic programs, regulations, and quality assurance.
• Instrumental in curriculum revisions to keep pace with industry trends and technological advancements.
• Managed admission processes, student evaluations, and academic support systems.
• Contributed significantly to maintaining IIITB's high academic standards.

## Professional Service and Recognition

• Serves on program committees for international conferences.
• Acts as a reviewer for prestigious journals.
• May hold memberships in professional bodies (e.g., ACM, IEEE).
• Recognized within the academic community for his expertise and contributions.

## Conclusion

• Prof. B. Thangaraju is a cornerstone of IIIT Bangalore's academic and research community.
• His expertise in Data Management and Analytics has significantly advanced the field.
• His leadership in academic administration has been invaluable to the institute.
• A dedicated educator, researcher, and mentor shaping the future of technology.

